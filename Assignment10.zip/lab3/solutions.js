{"solutions":[
	{
		"solution":"vProspect",
		"version":"2.0",
		"imagePath":"images/logo_vprospect.gif",
		"description":"Define and research your target audience, define your strategy to reach that audience and present a strong and memorable brand to that audience."
	},
	{
		"solution":"vConvert",
		"version":"2.0",
		"imagePath":"images/logo_vconvert.gif",
		"description":"Create a highly user-friendly and easy-to-navigate information architecture that will help your prospects interact with the company on a highly interactive level."
	},
	{
		"solution":"vRetain",
		"version":"1.0",
		"imagePath":"images/logo_vretain.gif",
		"description":"Build on existing customer relationships to improve productivity and maximize customer loyalty, while growing revenues."
	}
]}